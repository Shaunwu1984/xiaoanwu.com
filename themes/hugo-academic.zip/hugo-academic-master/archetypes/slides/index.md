+++
title = "{{ replace .Name "-" " " | title }}"
date = {{ .Date }}

# Add a summary (optional).
summary = ""

# Authors, tags, and categories
#   Use a comma separated list, e.g. `["Bob Smith", "David Jones"]`.
authors = []
tags = []
categories = []

[slides]
  # Choose a theme from https://github.com/hakimel/reveal.js#theming
  theme = "black"
  
  # Choose a code highlighting style (if highlighting enabled in `params.toml`)
  #   Light style: github. Dark style: dracula (default).
  highlight_style = "dracula"
+++

# Title

Author Name

---

## Slide 2
